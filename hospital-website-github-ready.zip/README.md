# Hospital Website

Proyecto web desarrollado con Next.js.

## Descripción
Sitio web de hospital / centro médico con interfaz moderna.

## Tecnologías usadas
- Next.js
- React
- CSS

## Cómo ejecutar el proyecto

npm install
npm run dev

Abrir en navegador:
http://localhost:3000
