"use client"

import { useState } from "react"
import { X, ChevronLeft, ChevronRight } from "lucide-react"

const galleryImages = [
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/3-nX9o0l1RthkwLhUyXxuawamRC8BOAk.jpeg",
    alt: "Fachada principal del Hospital Provincial Pascasio Toribio Piantini",
    caption: "Fachada Principal",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/5-acXUUKgNe8uRGdS5hTTfn46XftIdVV.jpeg",
    alt: "\u00c1rea de emergencia del hospital",
    caption: "\u00c1rea de Emergencia",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/4-kcCHWkUH7WfWLXLy0cvNstFyszr9RR.jpeg",
    alt: "Mural art\u00edstico en la fachada lateral del hospital",
    caption: "Mural Art\u00edstico",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/6-rAb8I9GXs2RaZO2Tf8akI3CsAwDYVz.jpeg",
    alt: "Unidad de Atenci\u00f3n al Usuario",
    caption: "Atenci\u00f3n al Usuario",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/2-BGoHu8nm66aiohiNSHRKM1N9bH2jRs.jpeg",
    alt: "Estaci\u00f3n de Enfermeras del hospital",
    caption: "Estaci\u00f3n de Enfermeras",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/8-DwoycP31syap7hm74ZX2PpUuuFDo8o.jpeg",
    alt: "Lobby y entrada principal con cartera de servicios",
    caption: "Lobby Principal",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/7-BsX62kaS9vwBvEcIdp5iocXVFA2qVt.jpeg",
    alt: "Pasillos del hospital con pacientes en espera",
    caption: "\u00c1rea de Consultas",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1-OMXR2G2OjHcclGc1AXaVhaE88J6Dif.jpeg",
    alt: "Almac\u00e9n de suministros m\u00e9dicos del hospital",
    caption: "Suministros M\u00e9dicos",
  },
]

export function GallerySection() {
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null)

  const openLightbox = (index: number) => setLightboxIndex(index)
  const closeLightbox = () => setLightboxIndex(null)
  const goNext = () =>
    setLightboxIndex((prev) =>
      prev !== null ? (prev + 1) % galleryImages.length : null
    )
  const goPrev = () =>
    setLightboxIndex((prev) =>
      prev !== null
        ? (prev - 1 + galleryImages.length) % galleryImages.length
        : null
    )

  return (
    <section id="instalaciones" className="py-20 lg:py-28 bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <p className="text-sm font-semibold tracking-widest uppercase text-primary mb-3">
            Nuestras Instalaciones
          </p>
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl text-foreground font-serif text-balance">
            Conoce Nuestro Hospital
          </h2>
          <p className="mt-4 text-lg text-muted-foreground leading-relaxed text-pretty">
            {"Contamos con instalaciones modernas y equipadas para brindar la mejor atenci\u00f3n a nuestros pacientes."}
          </p>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {galleryImages.map((image, index) => (
            <button
              key={index}
              onClick={() => openLightbox(index)}
              className={`group relative overflow-hidden rounded-xl cursor-pointer focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 ${
                index === 0
                  ? "sm:col-span-2 sm:row-span-2"
                  : ""
              }`}
            >
              <div className={`${index === 0 ? "aspect-square" : "aspect-[4/3]"} w-full`}>
                <img
                  src={image.src}
                  alt={image.alt}
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <div className="absolute inset-0 bg-foreground/0 group-hover:bg-foreground/40 transition-colors duration-300 flex items-end">
                <div className="p-4 w-full translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                  <p className="text-sm font-semibold text-primary-foreground">{image.caption}</p>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {lightboxIndex !== null && (
        <div className="fixed inset-0 z-[100] bg-foreground/90 flex items-center justify-center p-4">
          <button
            onClick={closeLightbox}
            className="absolute top-4 right-4 text-primary-foreground/80 hover:text-primary-foreground transition-colors z-10"
            aria-label="Cerrar"
          >
            <X className="h-8 w-8" />
          </button>

          <button
            onClick={goPrev}
            className="absolute left-4 text-primary-foreground/80 hover:text-primary-foreground transition-colors z-10"
            aria-label="Anterior"
          >
            <ChevronLeft className="h-10 w-10" />
          </button>

          <button
            onClick={goNext}
            className="absolute right-4 text-primary-foreground/80 hover:text-primary-foreground transition-colors z-10"
            aria-label="Siguiente"
          >
            <ChevronRight className="h-10 w-10" />
          </button>

          <div className="max-w-5xl max-h-[85vh] w-full">
            <img
              src={galleryImages[lightboxIndex].src}
              alt={galleryImages[lightboxIndex].alt}
              className="w-full h-auto max-h-[80vh] object-contain rounded-lg"
            />
            <p className="text-center mt-4 text-primary-foreground/80 text-sm font-medium">
              {galleryImages[lightboxIndex].caption}
            </p>
          </div>
        </div>
      )}
    </section>
  )
}
