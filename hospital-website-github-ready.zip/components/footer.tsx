import { Phone, MapPin, Clock } from "lucide-react"

const MAPS_URL =
  "https://www.google.com/maps/dir/19.3724416,-70.418432/Hospital+Provincial+Dr.+Pascasio+Toribio+Piantini,+Centro+de+Ciudad,+Av.+Duarte+106,+Salcedo+34000/@19.3772037,-70.4226815,16z/data=!3m1!4b1!4m9!4m8!1m1!4e1!1m5!1m1!1s0x8eae296fcb60e80d:0x9a2a71a8ee563a9f!2m2!1d-70.4167915!2d19.3822538?entry=ttu"

export function Footer() {
  return (
    <footer className="bg-foreground text-primary-foreground">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-3 mb-5">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
                <span className="text-xl font-bold text-primary-foreground font-serif">H</span>
              </div>
              <div>
                <p className="text-xs font-medium tracking-widest uppercase text-primary-foreground/50">Hospital Provincial</p>
                <p className="text-sm font-bold text-primary-foreground leading-tight">Pascasio Toribio Piantini</p>
              </div>
            </div>
            <p className="text-sm text-primary-foreground/60 leading-relaxed">
              {"Centro de salud comprometido con la excelencia m\u00e9dica y el bienestar de la comunidad dominicana."}
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-sm font-bold uppercase tracking-widest text-primary-foreground/80 mb-5">
              {"Enlaces R\u00e1pidos"}
            </h4>
            <ul className="flex flex-col gap-3">
              {[
                { label: "Inicio", href: "#inicio" },
                { label: "Sobre Nosotros", href: "#nosotros" },
                { label: "Servicios", href: "#servicios" },
                { label: "Instalaciones", href: "#instalaciones" },
                { label: "Contacto", href: "#contacto" },
              ].map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="text-sm text-primary-foreground/60 hover:text-primary transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-sm font-bold uppercase tracking-widest text-primary-foreground/80 mb-5">
              Servicios
            </h4>
            <ul className="flex flex-col gap-3">
              {[
                "Emergencias 24/7",
                "Medicina Interna",
                "Ginecolog\u00eda",
                "Cirug\u00eda General",
                "Laboratorio Cl\u00ednico",
                "Imagenolog\u00eda",
              ].map((service) => (
                <li key={service}>
                  <span className="text-sm text-primary-foreground/60">{service}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-sm font-bold uppercase tracking-widest text-primary-foreground/80 mb-5">
              Contacto
            </h4>
            <ul className="flex flex-col gap-4">
              <li className="flex items-start gap-3">
                <Phone className="h-4 w-4 mt-0.5 text-primary shrink-0" />
                <a href="tel:8095772327" className="text-sm text-primary-foreground/60 hover:text-primary transition-colors">(809) 577-2327</a>
              </li>
              <li className="flex items-start gap-3">
                <MapPin className="h-4 w-4 mt-0.5 text-primary shrink-0" />
                <a href={MAPS_URL} target="_blank" rel="noopener noreferrer" className="text-sm text-primary-foreground/60 hover:text-primary transition-colors">Av. Duarte 106, Salcedo 34000, Prov. Hermanas Mirabal, Rep. Dominicana</a>
              </li>
              <li className="flex items-start gap-3">
                <Clock className="h-4 w-4 mt-0.5 text-primary shrink-0" />
                <span className="text-sm text-primary-foreground/60">{"Abierto 24 horas, 7 d\u00edas a la semana"}</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-primary-foreground/10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-5">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            <p className="text-xs text-primary-foreground/40">
              {"Hospital Provincial Pascasio Toribio Piantini. Todos los derechos reservados."}
            </p>
            <p className="text-xs text-primary-foreground/40">
              {"Servicio Nacional de Salud - Rep\u00fablica Dominicana"}
            </p>
          </div>
        </div>
      </div>
    </footer>
  )
}
