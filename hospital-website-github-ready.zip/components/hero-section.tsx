import { Clock, MapPin, Phone } from "lucide-react"
import { Button } from "@/components/ui/button"

const PHONE_NUMBER = "(809) 577-2327"
const PHONE_LINK = "tel:8095772327"
const MAPS_URL =
  "https://www.google.com/maps/dir/19.3724416,-70.418432/Hospital+Provincial+Dr.+Pascasio+Toribio+Piantini,+Centro+de+Ciudad,+Av.+Duarte+106,+Salcedo+34000/@19.3772037,-70.4226815,16z/data=!3m1!4b1!4m9!4m8!1m1!4e1!1m5!1m1!1s0x8eae296fcb60e80d:0x9a2a71a8ee563a9f!2m2!1d-70.4167915!2d19.3822538?entry=ttu"

export function HeroSection() {
  return (
    <section id="inicio" className="relative min-h-[90vh] flex items-end overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/3-nX9o0l1RthkwLhUyXxuawamRC8BOAk.jpeg"
          alt="Fachada del Hospital Provincial Pascasio Toribio Piantini"
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-foreground/90 via-foreground/40 to-foreground/10" />
      </div>

      {/* Content */}
      <div className="relative z-10 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 pb-16 pt-32">
        <div className="max-w-2xl">
          <p className="mb-4 text-sm font-medium tracking-widest uppercase text-primary-foreground/70">
            Servicio Nacional de Salud
          </p>
          <h1 className="text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl text-primary-foreground font-serif text-balance">
            Hospital Provincial Pascasio Toribio Piantini
          </h1>
          <p className="mt-6 text-lg leading-relaxed text-primary-foreground/80 text-pretty">
            {"Comprometidos con la salud y el bienestar de nuestra comunidad, brindando servicios de calidad con calidez humana desde hace m\u00e1s de 50 a\u00f1os."}
          </p>

          <div className="mt-8 flex flex-col sm:flex-row gap-4">
            <Button size="lg" asChild className="bg-primary text-primary-foreground hover:bg-primary/90 gap-2 text-base">
              <a href={PHONE_LINK}>
                <Phone className="h-5 w-5" />
                Llamar Ahora
              </a>
            </Button>
            <Button size="lg" asChild className="bg-card text-foreground hover:bg-card/90 gap-2 text-base shadow-lg border border-border">
              <a href={MAPS_URL} target="_blank" rel="noopener noreferrer">
                <MapPin className="h-5 w-5 text-primary" />
                {"C\u00f3mo Llegar"}
              </a>
            </Button>
          </div>
        </div>

        {/* Info Cards */}
        <div className="mt-12 grid grid-cols-1 sm:grid-cols-3 gap-4">
          <a
            href={PHONE_LINK}
            className="flex items-center gap-4 rounded-xl bg-card/10 backdrop-blur-md border border-primary-foreground/10 p-4 hover:bg-card/20 transition-colors"
          >
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-primary/20">
              <Phone className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <p className="text-xs font-medium text-primary-foreground/60 uppercase tracking-wider">Emergencias 24/7</p>
              <p className="text-sm font-bold text-primary-foreground">{PHONE_NUMBER}</p>
            </div>
          </a>
          <div className="flex items-center gap-4 rounded-xl bg-card/10 backdrop-blur-md border border-primary-foreground/10 p-4">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-primary/20">
              <Clock className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <p className="text-xs font-medium text-primary-foreground/60 uppercase tracking-wider">Horario</p>
              <p className="text-sm font-bold text-primary-foreground">Lunes a Domingo, 24 Horas</p>
            </div>
          </div>
          <a
            href={MAPS_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-4 rounded-xl bg-card/10 backdrop-blur-md border border-primary-foreground/10 p-4 hover:bg-card/20 transition-colors"
          >
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-primary/20">
              <MapPin className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <p className="text-xs font-medium text-primary-foreground/60 uppercase tracking-wider">{"Ubicaci\u00f3n"}</p>
              <p className="text-sm font-bold text-primary-foreground">Salcedo, Prov. Hermanas Mirabal</p>
            </div>
          </a>
        </div>
      </div>
    </section>
  )
}
