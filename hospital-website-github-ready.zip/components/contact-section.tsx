import { MapPin, Phone, Clock, Mail } from "lucide-react"

const contactInfo = [
  {
    icon: Phone,
    label: "Tel\u00e9fono / Emergencias",
    value: "(809) 577-2327",
    description: "L\u00ednea directa para emergencias y consultas generales.",
    href: "tel:8095772327",
  },
  {
    icon: MapPin,
    label: "Direcci\u00f3n",
    value: "Av. Duarte 106, Salcedo 34000",
    description: "Provincia Hermanas Mirabal, Regi\u00f3n Nordeste, Rep\u00fablica Dominicana.",
    href: "https://www.google.com/maps/dir/19.3724416,-70.418432/Hospital+Provincial+Dr.+Pascasio+Toribio+Piantini,+Centro+de+Ciudad,+Av.+Duarte+106,+Salcedo+34000/@19.3772037,-70.4226815,16z/data=!3m1!4b1!4m9!4m8!1m1!4e1!1m5!1m1!1s0x8eae296fcb60e80d:0x9a2a71a8ee563a9f!2m2!1d-70.4167915!2d19.3822538?entry=ttu",
  },
  {
    icon: Clock,
    label: "Horario de Servicio",
    value: "24 Horas, 7 D\u00edas a la Semana",
    description: "Emergencias las 24 horas. Consultas externas de lunes a viernes.",
  },
  {
    icon: Mail,
    label: "Correo Electr\u00f3nico",
    value: "info@hospitalpiantini.gob.do",
    description: "Para consultas, sugerencias y solicitudes de informaci\u00f3n.",
  },
]

export function ContactSection() {
  return (
    <section id="contacto" className="py-20 lg:py-28 bg-secondary">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <p className="text-sm font-semibold tracking-widest uppercase text-primary mb-3">Contacto</p>
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl text-foreground font-serif text-balance">
            Estamos para Servirte
          </h2>
          <p className="mt-4 text-lg text-muted-foreground leading-relaxed text-pretty">
            {"Si necesitas informaci\u00f3n, una cita m\u00e9dica o tienes alguna consulta, no dudes en comunicarte con nosotros."}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Contact Info Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {contactInfo.map((item) => {
              const content = (
                <>
                  <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 text-primary mb-4">
                    <item.icon className="h-5 w-5" />
                  </div>
                  <p className="text-xs font-medium tracking-widest uppercase text-muted-foreground mb-1">
                    {item.label}
                  </p>
                  <p className="text-base font-bold text-foreground mb-2">{item.value}</p>
                  <p className="text-sm text-muted-foreground leading-relaxed">{item.description}</p>
                </>
              )

              if (item.href) {
                return (
                  <a
                    key={item.label}
                    href={item.href}
                    target={item.href.startsWith("tel:") ? undefined : "_blank"}
                    rel={item.href.startsWith("tel:") ? undefined : "noopener noreferrer"}
                    className="rounded-xl bg-card border border-border p-6 shadow-sm hover:shadow-md hover:border-primary/30 transition-all block"
                  >
                    {content}
                  </a>
                )
              }

              return (
                <div
                  key={item.label}
                  className="rounded-xl bg-card border border-border p-6 shadow-sm hover:shadow-md transition-shadow"
                >
                  {content}
                </div>
              )
            })}
          </div>

          {/* Emergency Image + CTA */}
          <div className="relative overflow-hidden rounded-2xl">
            <img
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/5-acXUUKgNe8uRGdS5hTTfn46XftIdVV.jpeg"
              alt="\u00c1rea de Emergencia del Hospital Pascasio Toribio Piantini"
              className="h-full w-full object-cover min-h-[400px]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 via-foreground/30 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-8">
              <h3 className="text-2xl font-bold text-primary-foreground font-serif mb-2">
                Emergencias las 24 Horas
              </h3>
              <p className="text-primary-foreground/80 mb-4 text-pretty">
                {"Nuestro equipo de emergencias est\u00e1 disponible las 24 horas del d\u00eda para atender cualquier situaci\u00f3n m\u00e9dica urgente."}
              </p>
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary">
                  <Phone className="h-5 w-5 text-primary-foreground" />
                </div>
                <div>
                  <p className="text-xs text-primary-foreground/60 uppercase tracking-wider">Llama ahora</p>
                  <a href="tel:8095772327" className="text-lg font-bold text-primary-foreground hover:underline">(809) 577-2327</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
