import { Target, Eye, Heart, Shield, Users, Star } from "lucide-react"

const values = [
  {
    icon: Heart,
    title: "Humanismo",
    description: "Tratamos a cada paciente con dignidad, respeto y empat\u00eda, reconociendo su valor como ser humano.",
  },
  {
    icon: Star,
    title: "Excelencia",
    description: "Buscamos la mejora continua en todos nuestros procesos para ofrecer atenci\u00f3n de la m\u00e1s alta calidad.",
  },
  {
    icon: Shield,
    title: "Integridad",
    description: "Actuamos con honestidad, transparencia y \u00e9tica en cada acci\u00f3n que realizamos.",
  },
  {
    icon: Users,
    title: "Compromiso Social",
    description: "Estamos dedicados al bienestar de nuestra comunidad, garantizando acceso a servicios de salud para todos.",
  },
]

export function AboutSection() {
  return (
    <section id="nosotros" className="py-20 lg:py-28 bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <p className="text-sm font-semibold tracking-widest uppercase text-primary mb-3">Sobre Nosotros</p>
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl text-foreground font-serif text-balance">
            {"M\u00e1s de 50 a\u00f1os al servicio de la salud"}
          </h2>
          <p className="mt-4 text-lg text-muted-foreground leading-relaxed text-pretty">
            {"El Hospital Provincial Pascasio Toribio Piantini, ubicado en Salcedo, Provincia Hermanas Mirabal, es un centro de salud de referencia en la regi\u00f3n Nordeste de la Rep\u00fablica Dominicana, brindando atenci\u00f3n m\u00e9dica integral a la comunidad."}
          </p>
        </div>

        {/* Mission & Vision */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-20">
          <div className="relative overflow-hidden rounded-2xl bg-primary p-8 lg:p-10">
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-6">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary-foreground/20">
                  <Target className="h-6 w-6 text-primary-foreground" />
                </div>
                <h3 className="text-2xl font-bold text-primary-foreground font-serif">{"Misi\u00f3n"}</h3>
              </div>
              <p className="text-primary-foreground/90 leading-relaxed text-pretty">
                {"Brindar servicios de salud de calidad, accesibles y oportunos a la poblaci\u00f3n de la regi\u00f3n Nordeste, con un equipo humano comprometido, calificado y en constante formaci\u00f3n, utilizando tecnolog\u00eda moderna para garantizar la satisfacci\u00f3n de nuestros usuarios y contribuir al bienestar de la comunidad."}
              </p>
            </div>
            <div className="absolute -bottom-8 -right-8 h-40 w-40 rounded-full bg-primary-foreground/5" />
            <div className="absolute -top-4 -left-4 h-24 w-24 rounded-full bg-primary-foreground/5" />
          </div>

          <div className="relative overflow-hidden rounded-2xl bg-card border border-border p-8 lg:p-10 shadow-sm">
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-6">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                  <Eye className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-2xl font-bold text-foreground font-serif">{"Visi\u00f3n"}</h3>
              </div>
              <p className="text-muted-foreground leading-relaxed text-pretty">
                {"Ser reconocido como el hospital provincial l\u00edder en la regi\u00f3n Nordeste, distingui\u00e9ndose por la excelencia en la atenci\u00f3n m\u00e9dica, la innovaci\u00f3n en los servicios de salud, y el compromiso con el desarrollo integral de nuestra comunidad, siendo un modelo de referencia en el sistema de salud p\u00fablica dominicano."}
              </p>
            </div>
            <div className="absolute -bottom-8 -right-8 h-40 w-40 rounded-full bg-primary/5" />
          </div>
        </div>

        {/* Values */}
        <div>
          <div className="text-center mb-12">
            <p className="text-sm font-semibold tracking-widest uppercase text-primary mb-3">Nuestros Principios</p>
            <h3 className="text-2xl font-bold tracking-tight sm:text-3xl text-foreground font-serif">Valores Institucionales</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value) => (
              <div
                key={value.title}
                className="group rounded-2xl bg-card border border-border p-6 shadow-sm hover:shadow-md transition-shadow hover:border-primary/30"
              >
                <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-primary/10 text-primary mb-5 group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                  <value.icon className="h-6 w-6" />
                </div>
                <h4 className="text-lg font-bold text-foreground mb-2">{value.title}</h4>
                <p className="text-sm text-muted-foreground leading-relaxed">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
