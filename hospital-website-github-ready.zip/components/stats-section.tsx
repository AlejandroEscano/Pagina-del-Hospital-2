const stats = [
  { value: "50+", label: "A\u00f1os de Servicio" },
  { value: "12+", label: "Especialidades M\u00e9dicas" },
  { value: "200+", label: "Personal de Salud" },
  { value: "24/7", label: "Servicio de Emergencia" },
]

export function StatsSection() {
  return (
    <section className="py-16 bg-primary">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat) => (
            <div key={stat.label} className="text-center">
              <p className="text-4xl sm:text-5xl font-bold text-primary-foreground font-serif">
                {stat.value}
              </p>
              <p className="mt-2 text-sm font-medium text-primary-foreground/70 tracking-wide">
                {stat.label}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
