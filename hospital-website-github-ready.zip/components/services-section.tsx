import {
  Stethoscope,
  Baby,
  Bone,
  Brain,
  HeartPulse,
  Syringe,
  Microscope,
  Ambulance,
  Pill,
  Scan,
  Activity,
  Eye,
} from "lucide-react"

const services = [
  {
    icon: Ambulance,
    title: "Emergencias 24/7",
    description: "Atenci\u00f3n de urgencias las 24 horas del d\u00eda, los 7 d\u00edas de la semana.",
  },
  {
    icon: Stethoscope,
    title: "Medicina Interna",
    description: "Diagn\u00f3stico y tratamiento de enfermedades en adultos.",
  },
  {
    icon: HeartPulse,
    title: "Cardiolog\u00eda",
    description: "Evaluaci\u00f3n y tratamiento de enfermedades del coraz\u00f3n.",
  },
  {
    icon: Baby,
    title: "Ginecolog\u00eda y Obstetricia",
    description: "Atenci\u00f3n especializada a la salud de la mujer y maternidad.",
  },
  {
    icon: Bone,
    title: "Ortopedia y Traumatolog\u00eda",
    description: "Tratamiento de fracturas, lesiones \u00f3seas y articulares.",
  },
  {
    icon: Syringe,
    title: "Cirug\u00eda General",
    description: "Procedimientos quir\u00fargicos con tecnolog\u00eda avanzada.",
  },
  {
    icon: Brain,
    title: "Neurolog\u00eda",
    description: "Diagn\u00f3stico y manejo de enfermedades del sistema nervioso.",
  },
  {
    icon: Microscope,
    title: "Laboratorio Cl\u00ednico",
    description: "An\u00e1lisis y pruebas de laboratorio con resultados confiables.",
  },
  {
    icon: Scan,
    title: "Imagenolog\u00eda",
    description: "Rayos X, ecograf\u00edas y estudios de diagn\u00f3stico por im\u00e1genes.",
  },
  {
    icon: Pill,
    title: "Farmacia",
    description: "Dispensaci\u00f3n de medicamentos y orientaci\u00f3n farmac\u00e9utica.",
  },
  {
    icon: Activity,
    title: "Cuidados Intensivos",
    description: "Unidad de cuidados intensivos para pacientes cr\u00edticos.",
  },
  {
    icon: Eye,
    title: "Oftalmolog\u00eda",
    description: "Atenci\u00f3n especializada en salud visual y ocular.",
  },
]

export function ServicesSection() {
  return (
    <section id="servicios" className="py-20 lg:py-28 bg-secondary">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <p className="text-sm font-semibold tracking-widest uppercase text-primary mb-3">Nuestros Servicios</p>
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl text-foreground font-serif text-balance">
            {"Cartera de Servicios M\u00e9dicos"}
          </h2>
          <p className="mt-4 text-lg text-muted-foreground leading-relaxed text-pretty">
            {"Contamos con una amplia gama de especialidades m\u00e9dicas y servicios de apoyo para atender todas las necesidades de salud de nuestra comunidad."}
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {services.map((service) => (
            <div
              key={service.title}
              className="group rounded-xl bg-card border border-border p-6 hover:shadow-lg transition-all hover:border-primary/30 hover:-translate-y-0.5"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 text-primary mb-4 group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                <service.icon className="h-5 w-5" />
              </div>
              <h3 className="text-base font-bold text-foreground mb-1.5">{service.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
